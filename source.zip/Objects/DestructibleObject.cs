using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestructibleObject : MonoBehaviour
{
    [SerializeField] int healthRestored = 0;
    [SerializeField] int energyRestored = 0;
    [SerializeField] int lightGranted = 0;
    
    private Animator animController;
    void Start()
    {
        animController = GetComponent<Animator>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "PlayerAttack")
        {
            animController.SetTrigger("Destroyed");
            Destroy(this);

            if(lightGranted > 0)
            {
                GrantLight();
            }

            if(healthRestored > 0)
            {
                RestoreHealth();
            }

            if(energyRestored > 0)
            {
                RestoreEnergy();
            }
        }
    }

    void GrantLight()
    {
        PlayerTracker.instance.lightAmount += lightGranted;
        UIController.instance.UpdateLightHud();
    }

    void RestoreHealth()
    {
        PlayerTracker.instance.health += healthRestored;

        if(PlayerTracker.instance.health > PlayerTracker.instance.maxHealth)
            PlayerTracker.instance.health = PlayerTracker.instance.maxHealth;

        UIController.instance.UpdateHealth(PlayerTracker.instance.health, PlayerTracker.instance.maxHealth);
    }

    void RestoreEnergy()
    {
        PlayerTracker.instance.energy += energyRestored;

        if(PlayerTracker.instance.energy > PlayerTracker.instance.maxEnergy)
            PlayerTracker.instance.energy = PlayerTracker.instance.maxEnergy;
        
        UIController.instance.UpdateEnergy(PlayerTracker.instance.energy, PlayerTracker.instance.maxEnergy);
    }
}
